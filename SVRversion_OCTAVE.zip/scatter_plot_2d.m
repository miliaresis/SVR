% reads two column vectors and the axes labels (labely, labelx) for each vector
% reads the legend and the filename (jpg) (that is saved to disk)
% open a new figure
% plots (x,y) pairs,
function  scatter_plot_2d(x,y, label1, label2, title1, filename_plot)
figure;                             % init a new figure window
plot(x, y, 'x', 'MarkerSize', 3);
ylabel(label1);
xlabel(label2);
title(title1);
print -djpg filename_plot
endfunction