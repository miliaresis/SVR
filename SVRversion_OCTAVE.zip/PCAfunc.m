% Computes the eigenvalues eigeV and eigenvectors eigenVal of a matrix LST (m*n)
function [D, V] = PCAfunc(LST)
mu = mean(LST);
Xm = bsxfun(@minus, LST, mu);
C = cov(Xm);
[V,D] = eig(C);
[D, i] = sort(diag(D), 'descend');
V = V(:, i);
endfunction