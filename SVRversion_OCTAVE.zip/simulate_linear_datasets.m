% simulate the equation y= θo*Xo+θ1*X1+θ2*X2+...θn*Xn (X0=1 or ao=constant term)
% provide the  feature space dimension (n - columns)
% provide the number of training data (m - rows)
% output is matrix X m*n -- m>n
%                  Y m*1 -the constant terms 
function [X,Y] = simulate_linear_datasets (m,n) 
% m=trainning samples, n=features
Coefs=zeros(1,n+1); 
X=zeros(m,n); 
XX=zeros(m,n+1); 
Y=zeros(m,1); B=zeros(m,1);
Coefs=ceil(30-20*rand(1,n+1));
X= floor(50+20*randn(m, n));
XX=[ones(m,1), X];           % add as first column the 1s to matrix XX
Y= XX*Coefs';      
B=200-200*randn(m,1);    
Y= Y.+B;   
endfunction