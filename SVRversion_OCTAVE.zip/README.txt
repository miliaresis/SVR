Selective Variance Reduction

It was build and tested in OCTAVE 4.0, https://www.gnu.org/software/octave/
(but it should be compatible for MATLAB too).

The main programs are
1. SVR_no_output.m [memory output]
2. SVR_with_output.m [file output, excel and mat files]
On the other hand all the functions included in the zip file should 
be available in the same directory or to a path denoted to OCTAVE.

See the Environmental Image Analysis web page for details
https://dl.dropboxusercontent.com/u/16217596/webOctave/_octave.html

California dataset (in the directory DATA) includes monthly 
LST for 2007, Elevation, Latitude and Longitude matrices.
A LAB exercise is available too as well as data documentation 
and references in the directory DOCUMENTATION.
OUTPUTS (excel and mat file) are provided too in the corresponding directory.

Jan, 2016
George Miliaresis
http://miliaresis.tripod.com
 