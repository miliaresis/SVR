% SOLVE NORMAL EQUATION x(m,n), y(m,1)
% computes the residuals image
function [theta, RMS, Resimage] = normal_equation_nm_residualimage(x,y)
m=size(x,1);   % training samples
n=size(x,2);   % features
XX=[ones(m,1), x];   % add 1s as the first column of new matrix XX
theta=pinv(XX'*XX)*(XX'*y);  % solve the linear system XX*theta=y
Resimage=(XX*theta).-y;
RMS= sqrt(sum(abs((XX*theta).-y).^2)/m);
endfunction