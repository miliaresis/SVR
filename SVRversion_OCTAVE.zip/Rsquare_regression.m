% Computes Rsquare for (Y, Yresiduals)  of dimensions (N*1)
% a function that normalizes the dataset is required 
% a function that computes crosscorrelation  is required 
% Output Rsq (R^2)
function [Rsq] = Rsquare_regression (Y, Yresidual)
LST=[Y, Yresidual];
[A_out, mean_vector, std_vector] = normalize_matrix(LST);
[Arows, Acols]=size(A_out);
X=A_out(:,1); Y=A_out(:,2);
Rsq=(X'*Y)/(Arows-1);
Rsq=Rsq*Rsq;
endfunction