% Translation of the random variables
% instead of  using the raw data, to use the difference between the
%  variables and their sample means. Translation does not affect the 
% interpretations because the variances of the original variables are 
% the same as those of the translated variable.
% Translation of each column (features, properties) of the matrix A m*n
% outputs= 1.transalted  matrix A_out(m*n) 2.mean_vector(1*n)
function [A_out, mean_vector] = normalize_matrix(A)
A_out = A;                            % init A_out
mean_vector = zeros(1,size(A_out,2)); % init mean_vector(1*n)=0
mean_vector=mean(A_out);  % compute mean for each column (mean=func)
A_out=A_out.-mean_vector;  % subtract column mean for column's elmnts
endfunction
