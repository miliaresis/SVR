function [theta, J_history] = gradientDescent(X, y, theta, alpha, num_iters)
m = length(y); % number of training examples
J_history = zeros(num_iters, 1);
temp=zeros(size(X,2),1);  
for iter = 1:num_iters
   for jj=1:size(X,2)
      temp(jj)= theta(jj) - (alpha/length(y)) *  sum((X*theta-y).*X(:,jj));
   end;
   theta= temp;   
   J_history(iter) = computeCost(X, y, theta);
end
endfunction
