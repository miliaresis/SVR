% Normalizes each column (features, properties) of the matrix X (m*n)
% outputs= 1.standardized matrix A_out(m*n) 2.mean_vector(1*n) 3.std_vector(1*n)
function [A_out, mean_vector, std_vector] = normalize_matrix(A)
A_out = A;                            % init A_out
mean_vector = zeros(1,size(A_out,2)); % init mean_vector(1*n)=0
std_vector =  zeros(1,size(A_out,2)); % init std_vector(1*n)=0
mean_vector=mean(A_out);              % compute mean for each column (mean=func)
std_vector=std(A_out);                % compute sdev for each column (std=func)
A_out=A_out.-mean_vector;             % subtract column mean for column's elmnts
A_out=A_out./std_vector;              % divide by column's st.deviation
endfunction
