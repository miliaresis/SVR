% write matrix to excell file
% the package <io>  is required
function  writematrixtoexcelfunc (A, excellfile1)
filename1= excellfile1;
if fexist(filename1) 
delete(filename1);
endif
xlswrite(filename1, A); 
endfunction
