% Computes cross corellation matric  of a data matrix of  n samples * m parameters
% a function that normalizes the dataset is required 
% outputs=  m*m  matrix 
function [cormatrix] = crosscorfunc(LST)
[A_out, mean_vector, std_vector] = normalize_matrix(LST);
[Arows, Acols]=size(A_out);
cormatrix=(A_out'*A_out)./(Arows-1);
endfunction