clear, clc;
%-----------------------------------------  LOAD REQUIRED package <io> 
%---------------------------- assuming that IO has been already installed
pkg load io                                               
%-------------- THE PATHS to addin functions is required   ...\functions
load california2.mat -mat  % read H, fφ λ & LST (Jan to DEC)
% ---------------------------------------CROSS CORRELATION MATRIX
LST2= [H, LAT, LON, LST];             
disp('cross correlation matrix: H,LAT,LON, LST(Jan:Dec)')
[cormatrix] = crosscorfunc(LST2);
writematrixtoexcelfunc(cormatrix, '1_crosscorrelation.xls');
clear LST2;  clear cormatrix;
%-----------------------------------------------Eigenvalues & Eigenvectors
[eigenValues, eigenVectors]=PCAfunc(LST);
disp('eigenvalues');
writematrixtoexcelfunc(eigenValues, '2_eigenvalues.xls');
disp('eigenvectors, COLS=PCs, ROWS=eigenvectors');
writematrixtoexcelfunc(eigenVectors, '2_eigenvectors.xls');
%---------------------------------------------------------------------- Scores
Scores=LST*eigenVectors;
% ------------------------------ Pc1 & Pc2 Regression versus H, LAT, LON
disp('Regression coefficients for PC1:f(H,LAT,LON)');
x=[H,LAT,LON];     y= Scores(: ,1);
[PC1regresscoef, RMSpc1, Resimagepc1] = normal_equation_nm_residualimage(x,y);
writematrixtoexcelfunc(PC1regresscoef, '3_PC1regresscoef.xls');
disp('Regression coefficients for PC2:f(H,LAT,LON)');
y= Scores(: ,2);
[PC2regresscoef, RMSpc2, Resimagepc2] = normal_equation_nm_residualimage(x,y);
writematrixtoexcelfunc(PC2regresscoef, '3_PC2regresscoef.xls');
clear RMSpc1; clear RMSpc2;
%--------------------------------------------------------------- Reconstruct
[srows,scols]=size(Scores);
Scores2=[Resimagepc1, Resimagepc2, Scores(:,3:scols)];
clear Resimagepc1;clear Resimagepc2;
clear scols;clear srows; clear x; clear y;
Reconstruct=Scores2*eigenVectors';
save svr_process.mat -mat % ---------------------SAVE worksapce