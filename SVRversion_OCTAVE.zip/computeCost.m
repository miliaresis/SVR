function J = computeCost(X, y, theta)
m = size(y,1); % number of training examples
J = 0;
J = sum((X*theta-y).^2)/(2*m);
endfunction
